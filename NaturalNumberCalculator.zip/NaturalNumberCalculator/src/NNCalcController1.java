import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Jagteshwar Singh
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {

        NaturalNumber topNum = model.top();
        NaturalNumber bottomNum = model.bottom();

        view.updateTopDisplay(topNum);
        view.updateBottomDisplay(bottomNum);

        if (topNum.compareTo(bottomNum) < 0) {
            view.updateSubtractAllowed(false);
        } else {
            view.updateSubtractAllowed(true);
        }

        if (bottomNum.isZero()) {
            view.updateDivideAllowed(false);
        } else {
            view.updateDivideAllowed(true);
        }

        if (bottomNum.compareTo(TWO) >= 0
                && bottomNum.compareTo(INT_LIMIT) <= 0) {
            view.updatePowerAllowed(true);
            view.updateRootAllowed(true);
        } else {
            view.updatePowerAllowed(false);
            view.updateRootAllowed(false);
        }

    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {

        // Get top and bottom variables
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Copy object value to the top variable
        top.copyFrom(bottom);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddEvent() {

        // Get top and bottom variables
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Add bottom to top and later transfer result to bottom to clear top
        top.add(bottom);
        bottom.transferFrom(top);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSubtractEvent() {

        // Get top and bottom variables
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        /*
         * Subtract bottom from top and later transfer result to bottom to clear
         * top
         */
        top.subtract(bottom);
        bottom.transferFrom(top);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processMultiplyEvent() {

        // Get top and bottom variables
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        /*
         * Multiply bottom with top and later transfer result to bottom to clear
         * top
         */
        top.multiply(bottom);
        bottom.transferFrom(top);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processDivideEvent() {

        // Get top and bottom variables
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        /*
         * Solve for the remainder and transfer it to top whereas the bottom
         * gets transfered the quotient
         */
        NaturalNumber rem = top.divide(bottom);
        bottom.transferFrom(top);
        top.transferFrom(rem);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processPowerEvent() {

        // Get top and bottom variables
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        /*
         * Raises top to the power of bottom and transfers to bottom the result
         * to clear top
         */
        top.power(bottom.toInt());
        bottom.transferFrom(top);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processRootEvent() {

        // Get top and bottom variables
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        /*
         * Calculates the bottom root of top and transfers to bottom to clear
         * top
         */
        top.root(bottom.toInt());
        bottom.transferFrom(top);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddNewDigitEvent(int digit) {

        // Gets the bottom variable
        NaturalNumber bottom = this.model.bottom();

        // Appends digit to the right end of bottom
        bottom.multiplyBy10(digit);

        // Updates storage and display
        updateViewToMatchModel(this.model, this.view);
    }

}
